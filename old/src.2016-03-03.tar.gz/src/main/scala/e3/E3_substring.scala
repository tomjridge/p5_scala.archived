package e3

object E3_substring {
  type Substring[S] = (S,Int,Int)
}